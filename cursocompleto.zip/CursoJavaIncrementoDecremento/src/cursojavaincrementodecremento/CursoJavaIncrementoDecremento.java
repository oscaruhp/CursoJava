/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cursojavaincrementodecremento;

/**
 *
 * @author oscaruh
 */
public class CursoJavaIncrementoDecremento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
       
      
        int NumeroImprimir;
        NumeroImprimir=5;
        // incremento en 1
        NumeroImprimir++;
        System.out.println("Valor del número :"+NumeroImprimir);
        // decremento en 1
        NumeroImprimir--;
        System.out.println("Valor del número :"+NumeroImprimir);
        // incremento en 1
        ++NumeroImprimir;
        System.out.println("Valor del número :"+NumeroImprimir);
        // decremento en 1
        --NumeroImprimir;
        System.out.println("Valor del número :"+NumeroImprimir);
      
        // incremento en n=5
        NumeroImprimir+=5;
        System.out.println("Valor del número :"+NumeroImprimir);
        // decremento en n=5
        NumeroImprimir-=5;
        System.out.println("Valor del número :"+NumeroImprimir);
        // multiplicación incremental   
        NumeroImprimir*=4;
        System.out.println("Valor del número :"+NumeroImprimir);   
         
    }
    
}
