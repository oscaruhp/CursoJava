/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cursojavavariables;

/**
 *
 * @author oscaruh
 */
public class CursoJavaVariables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          // Variables
        
        // entero
        int NumeroA;
        NumeroA=3;
        System.out.println("El Número es:"+NumeroA);
        
        // Double 
        double NumeroDecimal;
        NumeroDecimal=3.2;
        System.out.println("El número es:"+NumeroDecimal);
        
        // String ó cadena
        String Cadena;
        Cadena="Develoteca";
        System.out.println("El String que se escribio es:"+Cadena);
        
        // Booleano
        boolean Verdad;
        Verdad=true; // Tambien puede ser false o falso
        System.out.println("EL valor para boolean es: "+Verdad);
        
    }
    
}
